public interface FizzBuzzPrinter {
    void printFizzBuzz(int from, int to);
}
