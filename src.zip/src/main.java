class Main {
    public static void main(String[] args) {
        FizzBuzzPrinter printer = new ConsolePrinter();
        printer.printFizzBuzz(1,100);
    }
}
